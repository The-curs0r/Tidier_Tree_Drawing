var searchData=
[
  ['bresenhamcircle_68',['bresenhamCircle',['../bresenham_circle_8cpp.html#a1755cf34cef1d00bdf7aa82dad8cb60c',1,'bresenhamCircle(int xc, int yc, int r):&#160;bresenhamCircle.cpp'],['../bresenham_functions_8h.html#a56b9c600be11bb575e2ef6c02502096d',1,'bresenhamCircle(int, int, int):&#160;bresenhamCircle.cpp']]],
  ['bresenhamline_69',['bresenhamLine',['../bresenham_functions_8h.html#a60a98c6567ef36d494bee30b0b355ea6',1,'bresenhamLine(int, int, int, int, int):&#160;bresenhamLine.cpp'],['../bresenham_line_8cpp.html#a478c98b09f829f5abd2d9c286dd10787',1,'bresenhamLine(int g_xCoor1, int g_xCoor2, int g_yCoor1, int g_yCoor2, int radius):&#160;bresenhamLine.cpp']]]
];
