var searchData=
[
  ['setup_49',['setup',['../tidier_tree_drawing_8cpp.html#a0f367fbb6bfcabc40224c862ec9fe9a3',1,'tidierTreeDrawing.cpp']]],
  ['storxy_50',['storxy',['../tidier_tree_drawing_8cpp.html#aa5d47573ca77174585045549d021730f',1,'tidierTreeDrawing.cpp']]]
];
