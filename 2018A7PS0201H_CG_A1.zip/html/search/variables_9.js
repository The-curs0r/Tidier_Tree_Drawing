var searchData=
[
  ['yc_115',['yc',['../tidier_tree_drawing_8cpp.html#a8470a9f95ece04985a5031e745042b7e',1,'tidierTreeDrawing.cpp']]],
  ['ycoor_116',['ycoor',['../struct_node.html#a4a8bec6a7349e3872ff58ecd24d76e5c',1,'Node']]]
];
