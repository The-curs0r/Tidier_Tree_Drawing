var searchData=
[
  ['newextrem_38',['newExtrem',['../tidier_tree_drawing_8cpp.html#a8ecde5ef03ca781966e2438d67d1bfe8',1,'tidierTreeDrawing.cpp']]],
  ['newnode_39',['newNode',['../tidier_tree_drawing_8cpp.html#aecbac1d0371e24a351eb3621c3daf863',1,'tidierTreeDrawing.cpp']]],
  ['node_40',['Node',['../struct_node.html',1,'']]]
];
