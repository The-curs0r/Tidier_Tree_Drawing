var searchData=
[
  ['xc_113',['xc',['../tidier_tree_drawing_8cpp.html#af7601131832c4d97295f90019c8ff8fc',1,'tidierTreeDrawing.cpp']]],
  ['xcoor_114',['xcoor',['../struct_node.html#a69d2a2a1c464053826b269c285a54053',1,'Node']]]
];
