var searchData=
[
  ['radius_109',['radius',['../tidier_tree_drawing_8cpp.html#a395279899207ce7f17adf9fdb8ee97ee',1,'tidierTreeDrawing.cpp']]],
  ['rlink_110',['rlink',['../struct_node.html#a0ed3c7305b43527f0f237bbfd438b8f7',1,'Node']]],
  ['root_111',['root',['../tidier_tree_drawing_8cpp.html#acf0d3919268f1150a92ad7955b939468',1,'tidierTreeDrawing.cpp']]]
];
