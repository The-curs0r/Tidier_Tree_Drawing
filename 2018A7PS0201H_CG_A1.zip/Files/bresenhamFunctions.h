#ifndef BRESENHAMFUNCTION
#define BRESENHAMFUNCTION
    void bresenhamLine(int , int , int , int,int);
    void bresenhamCircle(int , int , int );
#endif
